# SVQuest

Fabric 1.21.1 client/server quest and unified feature GUI for the SVFrame Cobblemon server.

## Build

This project is built with Fabric Loom + Yarn mappings. No Minecraft/Fabric API compile stubs are used.

```bash
gradle --no-daemon clean remapJar sourcesJar
```

The same remapped JAR is installed on both client and server.
