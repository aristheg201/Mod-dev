package vn.svframe.mythicmobsfabric;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import vn.svframe.compat.YamlLite;
import vn.svframe.mythicmobsfabric.runtime.ActiveMobState;
import vn.svframe.mythicmobsfabric.runtime.MobDefinition;
import vn.svframe.mythicmobsfabric.runtime.platform.BuiltinConditions;
import vn.svframe.mythicmobsfabric.runtime.platform.BuiltinMechanics;
import vn.svframe.mythicmobsfabric.runtime.platform.BuiltinTargeters;
import vn.svframe.mythicmobsfabric.runtime.platform.CoreConditionExtensions;
import vn.svframe.mythicmobsfabric.runtime.platform.CoreMechanicExtensions;
import vn.svframe.mythicmobsfabric.runtime.platform.CoreTargeterExtensions;
import vn.svframe.mythicmobsfabric.runtime.skill.MythicRuntimeState;
import vn.svframe.mythicmobsfabric.runtime.skill.MythicSkillCompiler;
import vn.svframe.mythicmobsfabric.runtime.skill.MythicSkillEngine;
import vn.svframe.mythicmobsfabric.runtime.skill.SkillContext;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class MythicMobsFabricMod implements ModInitializer {
    public static final String ID = "mythicmobsfabric";
    private static final Logger LOG = Logger.getLogger("MythicMobs-Fabric");
    private static final Path ROOT = FabricLoader.getInstance().getConfigDir().resolve("MythicMobs");
    private static final String TAG_PREFIX = "mythicmob.";
    private static final Map<String, MobRecord> MOBS = new ConcurrentHashMap<>();
    private static final Map<UUID, ActiveMobState> ACTIVE = new ConcurrentHashMap<>();
    private static final Map<UUID, MobRecord> ACTIVE_RECORDS = new ConcurrentHashMap<>();
    private static final ConcurrentLinkedQueue<Scheduled> SCHEDULED = new ConcurrentLinkedQueue<>();
    private static volatile MythicSkillEngine engine = new MythicSkillEngine();
    private static volatile MythicRuntimeState runtimeState = new MythicRuntimeState();
    private static volatile FabricMythicPlatform platform = new FabricMythicPlatform();
    private static volatile MinecraftServer server;
    private static volatile int loadedSkillCount;
    private static long ticks;

    @Override public void onInitialize() {
        reload();
        ServerLifecycleEvents.SERVER_STARTED.register(value -> { server = value; LOG.info("MythicMobs Fabric online; " + definitionSummary()); });
        ServerLifecycleEvents.SERVER_STOPPING.register(value -> { server = null; ACTIVE.clear(); ACTIVE_RECORDS.clear(); SCHEDULED.clear(); });
        ServerEntityEvents.ENTITY_LOAD.register(MythicMobsFabricMod::onEntityLoad);
        ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> { ACTIVE.remove(entity.getUuid()); ACTIVE_RECORDS.remove(entity.getUuid()); });
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {
            MobRecord victim = ACTIVE_RECORDS.get(entity.getUuid());
            Entity attacker = source.getAttacker();
            UUID attackerId = attacker == null ? null : attacker.getUuid();
            platform.recordDamage(entity.getUuid(), source.getName(), damageTaken);
            if (victim != null) fire(entity.getUuid(), victim, "ondamaged", attackerId);
            if (attacker != null) {
                MobRecord attacking = ACTIVE_RECORDS.get(attacker.getUuid());
                if (attacking != null) fire(attacker.getUuid(), attacking, "onattack", entity.getUuid());
            }
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            MobRecord record = ACTIVE_RECORDS.get(entity.getUuid());
            UUID killer = source.getAttacker() == null ? null : source.getAttacker().getUuid();
            if (record != null) fire(entity.getUuid(), record, "ondeath", killer);
            ACTIVE.remove(entity.getUuid()); ACTIVE_RECORDS.remove(entity.getUuid());
        });
        ServerTickEvents.END_SERVER_TICK.register(value -> {
            ticks++;
            runtimeState.purge(System.currentTimeMillis());
            runScheduled();
            for (Map.Entry<UUID, MobRecord> entry : ACTIVE_RECORDS.entrySet()) fireTimers(entry.getKey(), entry.getValue());
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(literal("mythicmobs")
                .requires(source -> source.hasPermissionLevel(2))
                .then(literal("status").executes(ctx -> { ctx.getSource().sendFeedback(() -> Text.literal("MythicMobs Fabric | " + definitionSummary()), false); return 1; }))
                .then(literal("reload").executes(ctx -> {
                    boolean ok = reload(); if (!ok) { ctx.getSource().sendError(Text.literal("MythicMobs reload failed.")); return 0; }
                    ctx.getSource().sendFeedback(() -> Text.literal("MythicMobs reloaded | " + definitionSummary()), true); return 1;
                }))
                .then(literal("mob").then(literal("spawn")
                        .then(argument("id", StringArgumentType.word()).executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                            UUID uuid = spawn(StringArgumentType.getString(ctx, "id"), player.getServerWorld(), player.getX(), player.getY(), player.getZ(), 1);
                            if (uuid == null) { ctx.getSource().sendError(Text.literal("Unknown or invalid MythicMob.")); return 0; }
                            return 1;
                        }).then(argument("level", IntegerArgumentType.integer(1, 10000)).executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                            UUID uuid = spawn(StringArgumentType.getString(ctx, "id"), player.getServerWorld(), player.getX(), player.getY(), player.getZ(), IntegerArgumentType.getInteger(ctx, "level"));
                            return uuid == null ? 0 : 1;
                        })))))
                .then(literal("skill").then(literal("cast").then(argument("id", StringArgumentType.word())
                        .executes(ctx -> { ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow(); return castExternal(StringArgumentType.getString(ctx, "id"), player.getUuid(), player.getUuid(), Map.of()) ? 1 : 0; })
                        .then(argument("target", EntityArgumentType.entity()).executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow(); Entity target = EntityArgumentType.getEntity(ctx, "target");
                            return castExternal(StringArgumentType.getString(ctx, "id"), player.getUuid(), target.getUuid(), Map.of()) ? 1 : 0;
                        })))))));
    }

    public static MinecraftServer server() { return server; }
    public static long ticks() { return ticks; }
    public static MythicRuntimeState runtimeState() { return runtimeState; }
    public static String definitionSummary() { return "mobs=" + MOBS.size() + ",skills=" + loadedSkillCount + ",active=" + ACTIVE.size(); }
    public static boolean hasMob(String id) { return MOBS.containsKey(norm(id)); }
    public static boolean hasSkill(String id) { return engine.skill(id).isPresent(); }
    public static int activeCount() { return ACTIVE.size(); }
    static ActiveMobState active(UUID uuid) { return ACTIVE.get(uuid); }
    static Collection<UUID> activeIds() { return List.copyOf(ACTIVE.keySet()); }

    public static boolean castExternal(String id, UUID caster, UUID target, Map<String, ?> parameters) {
        SkillContext context = new SkillContext(caster, target == null ? caster : target);
        context.entityTargets().add(target == null ? caster : target);
        if (parameters != null) context.vars().putAll(parameters);
        return engine.cast(id, context);
    }

    public static UUID spawn(String id, ServerWorld world, double x, double y, double z, int level) {
        MobRecord record = MOBS.get(norm(id));
        if (record == null) return null;
        EntityType<?> type = Registries.ENTITY_TYPE.get(identifier(record.definition.baseType()));
        if (type == EntityType.PIG && !record.definition.baseType().equalsIgnoreCase("PIG") && !record.definition.baseType().equalsIgnoreCase("minecraft:pig")) {
            Identifier requested = identifier(record.definition.baseType());
            if (!Registries.ENTITY_TYPE.containsId(requested)) return null;
        }
        Entity entity = type.spawn(world, BlockPos.ofFloored(x, y, z), SpawnReason.COMMAND);
        if (entity == null) return null;
        entity.refreshPositionAndAngles(x, y, z, entity.getYaw(), entity.getPitch());
        entity.addCommandTag(tag(record.definition.id()));
        activate(entity, record);
        applyDefinition(entity, record.definition, level);
        fire(entity.getUuid(), record, "onspawn", null);
        return entity.getUuid();
    }

    public static void remove(UUID uuid) {
        Entity entity = platform.entity(uuid); if (entity != null) entity.discard(); ACTIVE.remove(uuid); ACTIVE_RECORDS.remove(uuid);
    }
    public static void schedule(int delayTicks, Runnable task) { if (delayTicks <= 0) { task.run(); return; } SCHEDULED.add(new Scheduled(ticks + delayTicks, task)); }
    public static void signal(UUID target, String signal, UUID source) {
        MobRecord record = ACTIVE_RECORDS.get(target); if (record == null) return;
        platform.recordSignal(target, signal); fire(target, record, "onsignal:" + signal.toLowerCase(Locale.ROOT), source);
    }

    private static boolean reload() {
        try {
            FabricMythicPlatform nextPlatform = new FabricMythicPlatform();
            MythicRuntimeState nextState = new MythicRuntimeState();
            MythicSkillEngine nextEngine = new MythicSkillEngine();
            BuiltinMechanics.install(nextEngine, nextPlatform); BuiltinConditions.install(nextEngine, nextPlatform); BuiltinTargeters.install(nextEngine, nextPlatform);
            CoreMechanicExtensions.install(nextEngine, nextPlatform, nextState); CoreConditionExtensions.install(nextEngine, nextPlatform, nextState); CoreTargeterExtensions.install(nextEngine, nextPlatform);
            int nextSkillCount = loadSkills(nextEngine, ROOT.resolve("Skills"));
            Map<String, MobRecord> nextMobs = loadMobs(nextEngine, ROOT.resolve("Mobs"));
            platform = nextPlatform; runtimeState = nextState; engine = nextEngine; loadedSkillCount = nextSkillCount; MOBS.clear(); MOBS.putAll(nextMobs);
            return true;
        } catch (Exception e) { LOG.log(Level.SEVERE, "Failed to load MythicMobs legacy configuration", e); return false; }
    }

    private static int loadSkills(MythicSkillEngine target, Path directory) throws IOException {
        int count = 0;
        for (Path file : yamlFiles(directory)) {
            Map<String, Object> root = YamlLite.map(YamlLite.parse(file));
            for (Map.Entry<String, Object> entry : root.entrySet()) {
                if (!(entry.getValue() instanceof Map<?, ?> raw)) continue;
                @SuppressWarnings("unchecked") Map<String, Object> section = (Map<String, Object>) raw;
                List<String> conditions = strings(first(section, "Conditions", "conditions"));
                List<MythicSkillEngine.Line> lines = new ArrayList<>();
                for (String line : strings(first(section, "Skills", "skills"))) lines.add(MythicSkillCompiler.compileLine(line, conditions));
                target.skill(new MythicSkillEngine.Skill(entry.getKey(), List.copyOf(lines)));
                count++;
            }
        }
        return count;
    }

    private static Map<String, MobRecord> loadMobs(MythicSkillEngine target, Path directory) throws IOException {
        Map<String, MobRecord> result = new LinkedHashMap<>();
        for (Path file : yamlFiles(directory)) {
            Map<String, Object> root = YamlLite.map(YamlLite.parse(file));
            for (Map.Entry<String, Object> entry : root.entrySet()) {
                if (!(entry.getValue() instanceof Map<?, ?> raw)) continue;
                @SuppressWarnings("unchecked") Map<String, Object> section = (Map<String, Object>) raw;
                Map<String, Object> options = new LinkedHashMap<>(map(first(section, "Options", "options")));
                Object display = first(section, "Display", "display", "Name", "name"); if (display != null) options.put("display", display);
                MobDefinition definition = new MobDefinition(entry.getKey(), text(first(section, "Type", "type", "Mobtype", "mobtype"), "PIG"), number(first(section, "Health", "health"), 20), number(first(section, "Damage", "damage"), 0), text(first(section, "Faction", "faction"), ""), Map.copyOf(options));
                List<Triggered> triggers = new ArrayList<>(); int index = 0;
                for (String rawSkill : strings(first(section, "Skills", "skills"))) {
                    TriggerParts parts = splitTrigger(rawSkill); if (parts == null) continue;
                    String synthetic = "__mob__" + norm(entry.getKey()).replaceAll("[^a-z0-9_]", "_") + "__" + index++;
                    target.skill(new MythicSkillEngine.Skill(synthetic, List.of(MythicSkillCompiler.compileLine(parts.line, List.of()))));
                    triggers.add(new Triggered(parts.trigger, synthetic, parts.chance));
                }
                result.put(norm(entry.getKey()), new MobRecord(definition, List.copyOf(triggers)));
            }
        }
        return result;
    }

    private static void onEntityLoad(Entity entity, ServerWorld world) {
        for (String value : entity.getCommandTags()) {
            if (!value.startsWith(TAG_PREFIX)) continue;
            String id = untag(value); MobRecord record = MOBS.get(norm(id));
            if (record != null) { activate(entity, record); return; }
        }
    }
    private static void activate(Entity entity, MobRecord record) {
        ACTIVE.put(entity.getUuid(), new ActiveMobState(entity.getUuid(), record.definition)); ACTIVE_RECORDS.put(entity.getUuid(), record);
    }
    private static void applyDefinition(Entity entity, MobDefinition definition, int level) {
        if (entity instanceof LivingEntity living) {
            var maxHealth = living.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
            if (maxHealth != null) maxHealth.setBaseValue(Math.max(1, definition.health()));
            living.setHealth((float) Math.min(living.getMaxHealth(), Math.max(1, definition.health())));
        }
        if (entity instanceof MobEntity mob) {
            Object noAi = definition.options().get("NoAI"); if (noAi instanceof Boolean flag) mob.setAiDisabled(flag);
        }
        Object display = definition.options().get("display"); if (display != null) { entity.setCustomName(Text.literal(stripTags(String.valueOf(display)))); entity.setCustomNameVisible(true); }
        ACTIVE.computeIfAbsent(entity.getUuid(), uuid -> new ActiveMobState(uuid, definition)).vars().put("level", level);
    }
    private static void fire(UUID caster, MobRecord record, String trigger, UUID other) {
        String normalized = trigger.toLowerCase(Locale.ROOT);
        for (Triggered entry : record.triggers) {
            if (!entry.trigger.equals(normalized) || Math.random() > entry.chance) continue;
            SkillContext context = new SkillContext(caster, other == null ? caster : other); context.entityTargets().add(other == null ? caster : other); engine.cast(entry.skillId, context);
        }
    }
    private static void fireTimers(UUID uuid, MobRecord record) {
        for (Triggered entry : record.triggers) {
            if (!entry.trigger.startsWith("ontimer:") || Math.random() > entry.chance) continue;
            int period = integer(entry.trigger.substring("ontimer:".length()), 1); if (period > 0 && ticks % period == 0) {
                SkillContext context = new SkillContext(uuid, uuid); context.entityTargets().add(uuid); engine.cast(entry.skillId, context);
            }
        }
    }
    private static void runScheduled() {
        int size = SCHEDULED.size(); for (int i = 0; i < size; i++) { Scheduled task = SCHEDULED.poll(); if (task == null) break; if (task.tick <= ticks) { try { task.task.run(); } catch (Throwable t) { LOG.log(Level.SEVERE, "MythicMobs scheduled task failed", t); } } else SCHEDULED.add(task); }
    }
    private static TriggerParts splitTrigger(String raw) {
        int depth = 0; boolean quote = false; char quoteChar = 0;
        for (int i = 0; i < raw.length(); i++) { char c = raw.charAt(i); if ((c == '\'' || c == '"') && (i == 0 || raw.charAt(i - 1) != '\\')) { if (!quote) { quote = true; quoteChar = c; } else if (quoteChar == c) quote = false; } if (quote) continue; if (c == '{') depth++; else if (c == '}') depth = Math.max(0, depth - 1); else if (c == '~' && depth == 0) { String line = raw.substring(0, i).trim(); String rest = raw.substring(i + 1).trim(); if (line.isEmpty() || rest.isEmpty()) return null; String[] tokens = rest.split("\\s+"); String trigger = tokens[0].toLowerCase(Locale.ROOT); double chance = 1.0; if (tokens.length > 1) { try { chance = Double.parseDouble(tokens[1]); } catch (NumberFormatException ignored) {} } return new TriggerParts(line, trigger, Math.max(0.0, Math.min(1.0, chance))); } }
        return null;
    }
    private static Object first(Map<String, Object> map, String... keys) { for (String key : keys) if (map.containsKey(key)) return map.get(key); return null; }
    @SuppressWarnings("unchecked") private static Map<String, Object> map(Object value) { return value instanceof Map<?, ?> raw ? (Map<String, Object>) raw : Map.of(); }
    private static List<String> strings(Object value) { if (value instanceof Collection<?> collection) return collection.stream().map(String::valueOf).toList(); return value == null ? List.of() : List.of(String.valueOf(value)); }
    private static String text(Object value, String fallback) { return value == null ? fallback : String.valueOf(value); }
    private static double number(Object value, double fallback) { if (value instanceof Number number) return number.doubleValue(); try { return value == null ? fallback : Double.parseDouble(String.valueOf(value)); } catch (NumberFormatException e) { return fallback; } }
    private static int integer(String value, int fallback) { try { return Integer.parseInt(value); } catch (NumberFormatException e) { return fallback; } }
    private static List<Path> yamlFiles(Path directory) throws IOException { if (!Files.isDirectory(directory)) return List.of(); try (var stream = Files.walk(directory)) { return stream.filter(Files::isRegularFile).filter(path -> path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".yml")).sorted().toList(); } }
    private static String norm(String value) { return value == null ? "" : value.trim().toLowerCase(Locale.ROOT); }
    private static Identifier identifier(String raw) { String value = raw == null ? "pig" : raw.trim().toLowerCase(Locale.ROOT).replace(' ', '_'); return Identifier.of(value.contains(":") ? value : "minecraft:" + value); }
    private static String tag(String id) { return TAG_PREFIX + Base64.getUrlEncoder().withoutPadding().encodeToString(id.getBytes(StandardCharsets.UTF_8)); }
    private static String untag(String value) { try { return new String(Base64.getUrlDecoder().decode(value.substring(TAG_PREFIX.length())), StandardCharsets.UTF_8); } catch (IllegalArgumentException e) { return ""; } }
    private static String stripTags(String value) { return value.replaceAll("<[^>]+>", "").replaceAll("&[0-9A-FK-ORa-fk-or]", ""); }
    private record MobRecord(MobDefinition definition, List<Triggered> triggers) {}
    private record Triggered(String trigger, String skillId, double chance) {}
    private record TriggerParts(String line, String trigger, double chance) {}
    private record Scheduled(long tick, Runnable task) {}
}
