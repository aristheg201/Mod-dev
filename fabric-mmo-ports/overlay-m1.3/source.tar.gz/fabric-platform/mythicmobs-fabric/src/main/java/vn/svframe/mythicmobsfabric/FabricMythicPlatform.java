package vn.svframe.mythicmobsfabric;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import vn.svframe.mythicmobsfabric.runtime.ActiveMobState;
import vn.svframe.mythicmobsfabric.runtime.platform.MythicPlatform;
import vn.svframe.mythicmobsfabric.runtime.skill.SkillContext;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

final class FabricMythicPlatform implements MythicPlatform {
    private final Map<UUID, String> signals = new ConcurrentHashMap<>();
    private final Map<UUID, String> damageCauses = new ConcurrentHashMap<>();
    private final Map<UUID, Double> damageAmounts = new ConcurrentHashMap<>();
    private final Map<UUID, Map<UUID, Double>> threat = new ConcurrentHashMap<>();

    @Override public void damage(UUID target, double amount, boolean ignoreArmor) {
        Entity entity = entity(target); if (entity instanceof LivingEntity living && amount > 0) living.damage(living.getDamageSources().generic(), (float) amount);
    }
    @Override public void heal(UUID target, double amount) { Entity entity = entity(target); if (entity instanceof LivingEntity living && amount > 0) living.heal((float) amount); }
    @Override public void message(UUID target, String message) { Entity entity = entity(target); if (entity instanceof ServerPlayerEntity player) player.sendMessage(Text.literal(message), false); }
    @Override public void sound(SkillContext.Point point, String sound, float volume, float pitch) {
        ServerWorld world = world(point); if (world == null) return; var event = Registries.SOUND_EVENT.get(identifier(sound)); world.playSound(null, point.x(), point.y(), point.z(), event, SoundCategory.HOSTILE, volume, pitch);
    }
    @Override public void particle(SkillContext.Point point, String particle, int count, double spread) {
        ServerWorld world = world(point); if (world == null) return; Object value = Registries.PARTICLE_TYPE.get(identifier(particle)); if (value instanceof ParticleEffect effect) world.spawnParticles(effect, point.x(), point.y(), point.z(), Math.max(1, count), spread, spread, spread, 0.0);
    }
    @Override public void teleport(UUID target, SkillContext.Point point) { Entity entity = entity(target); if (entity != null) entity.refreshPositionAndAngles(point.x(), point.y(), point.z(), entity.getYaw(), entity.getPitch()); }
    @Override public void velocity(UUID target, double x, double y, double z) { Entity entity = entity(target); if (entity != null) entity.setVelocity(x, y, z); }
    @Override public void potion(UUID target, String effect, int duration, int amplifier) {
        Entity entity = entity(target); if (!(entity instanceof LivingEntity living)) return;
        Registries.STATUS_EFFECT.getEntry(identifier(effect)).ifPresent(entry -> living.addStatusEffect(new StatusEffectInstance(entry, Math.max(1, duration), Math.max(0, amplifier))));
    }
    @Override public void summon(String mob, SkillContext.Point point, int amount) {
        ServerWorld world = world(point); if (world == null) return; for (int i = 0; i < Math.max(1, amount); i++) MythicMobsFabricMod.spawn(mob, world, point.x(), point.y(), point.z(), 1);
    }
    @Override public void setVariable(UUID target, String name, Object value) { ActiveMobState state = active(target); if (state != null) state.vars().put(name, value); }
    @Override public void tag(UUID target, String tag, boolean add) { Entity entity = entity(target); if (entity == null) return; if (add) entity.addCommandTag(tag); else entity.removeCommandTag(tag); ActiveMobState state = active(target); if (state != null) { if (add) state.tags().add(tag); else state.tags().remove(tag); } }
    @Override public void setStance(UUID target, String stance) { ActiveMobState state = active(target); if (state != null) state.stance(stance); }
    @Override public void delay(int ticks, Runnable task) { MythicMobsFabricMod.schedule(ticks, task); }

    @Override public void removeEntity(UUID target) { MythicMobsFabricMod.remove(target); }
    @Override public void cancelEvent(SkillContext context) { context.vars().put("cancelled", true); }
    @Override public void equip(UUID target, String slot, String itemId) {
        Entity entity = entity(target); if (!(entity instanceof LivingEntity living)) return; Item item = Registries.ITEM.get(identifier(itemId)); ItemStack stack = new ItemStack(item);
        String normalized = slot == null ? "" : slot.toLowerCase(Locale.ROOT);
        if (normalized.contains("head") || normalized.contains("helmet")) living.equipStack(net.minecraft.entity.EquipmentSlot.HEAD, stack);
        else if (normalized.contains("chest")) living.equipStack(net.minecraft.entity.EquipmentSlot.CHEST, stack);
        else if (normalized.contains("leg")) living.equipStack(net.minecraft.entity.EquipmentSlot.LEGS, stack);
        else if (normalized.contains("feet") || normalized.contains("boot")) living.equipStack(net.minecraft.entity.EquipmentSlot.FEET, stack);
        else if (normalized.contains("off")) living.equipStack(net.minecraft.entity.EquipmentSlot.OFFHAND, stack);
        else living.equipStack(net.minecraft.entity.EquipmentSlot.MAINHAND, stack);
    }
    @Override public void look(UUID source, UUID target, double yawSpeed, double pitchSpeed) {
        Entity a = entity(source), b = entity(target); if (a == null || b == null) return; Vec3d d = b.getEyePos().subtract(a.getEyePos()); double horizontal = Math.sqrt(d.x * d.x + d.z * d.z); a.setYaw((float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90)); a.setPitch((float) -Math.toDegrees(Math.atan2(d.y, horizontal)));
    }
    @Override public void stun(UUID target, int ticks, boolean stopAi, boolean stopGravity) {
        Entity entity = entity(target); if (entity == null) return; if (stopAi && entity instanceof MobEntity mob) mob.setAiDisabled(true); if (stopGravity) entity.setNoGravity(true);
        MythicMobsFabricMod.schedule(Math.max(1, ticks), () -> { Entity current = entity(target); if (current instanceof MobEntity mob) mob.setAiDisabled(false); if (current != null) current.setNoGravity(false); });
    }
    @Override public void signal(UUID target, String signal, UUID source) { recordSignal(target, signal); MythicMobsFabricMod.signal(target, signal, source); }
    @Override public void threat(UUID source, UUID target, double amount, boolean set) {
        Map<UUID, Double> table = threat.computeIfAbsent(source, ignored -> new ConcurrentHashMap<>()); if (set) table.put(target, amount); else table.merge(target, amount, Double::sum);
        Entity caster = entity(source), victim = entity(target); if (caster instanceof MobEntity mob && victim instanceof LivingEntity living) mob.setTarget(living);
    }
    @Override public void clearThreat(UUID source) { threat.remove(source); Entity entity = entity(source); if (entity instanceof MobEntity mob) mob.setTarget(null); }
    @Override public void consume(UUID target, String itemId, int amount) {
        Entity entity = entity(target); if (!(entity instanceof ServerPlayerEntity player)) return; Identifier id = identifier(itemId); int left = Math.max(1, amount);
        for (int i = 0; i < player.getInventory().size() && left > 0; i++) { ItemStack stack = player.getInventory().getStack(i); if (!Registries.ITEM.getId(stack.getItem()).equals(id)) continue; int remove = Math.min(left, stack.getCount()); stack.decrement(remove); left -= remove; }
    }
    @Override public void giveItem(UUID target, String itemId, int amount) { Entity entity = entity(target); if (entity instanceof ServerPlayerEntity player) { ItemStack stack = new ItemStack(Registries.ITEM.get(identifier(itemId)), Math.max(1, amount)); if (!player.getInventory().insertStack(stack)) player.dropItem(stack, false); } }
    @Override public void dropItem(SkillContext.Point point, String itemId, int amount) { ServerWorld world = world(point); if (world == null) return; net.minecraft.entity.ItemEntity item = new net.minecraft.entity.ItemEntity(world, point.x(), point.y(), point.z(), new ItemStack(Registries.ITEM.get(identifier(itemId)), Math.max(1, amount))); world.spawnEntity(item); }
    @Override public void weather(String worldName, String type, int duration) { ServerWorld world = world(); if (world == null) return; String n = type == null ? "" : type.toLowerCase(Locale.ROOT); world.setWeather(n.contains("clear") ? duration : 0, n.contains("rain") || n.contains("storm") ? duration : 0, n.contains("rain") || n.contains("storm"), n.contains("thunder") || n.contains("storm")); }
    @Override public void projectile(String kind, Map<String, String> params, SkillContext context) {
        UUID caster = context.caster(); SkillContext.Point start = position(caster); Entity entity = entity(caster); if (entity == null) return; Vec3d direction = entity.getRotationVec(1.0F).normalize(); double speed = number(params, "velocity", number(params, "v", 1.0)); double range = number(params, "range", 24.0); double hitRadius = number(params, "hitradius", 1.0); String onHit = first(params, "onhit", "oh", "skill");
        class Flight implements Runnable { SkillContext.Point point = start; double traveled; @Override public void run() { if (traveled >= range) return; point = new SkillContext.Point(point.world(), point.x() + direction.x * speed, point.y() + direction.y * speed, point.z() + direction.z * speed); traveled += speed; Collection<UUID> near = entitiesInRadius(point, hitRadius, false); for (UUID id : near) if (!id.equals(caster)) { if (onHit != null) MythicMobsFabricMod.castExternal(onHit, caster, id, context.vars()); return; } MythicMobsFabricMod.schedule(1, this); } }
        MythicMobsFabricMod.schedule(1, new Flight());
    }
    @Override public void totem(Map<String, String> params, SkillContext context) { String skill = first(params, "ontick", "ot", "skill"); int interval = (int) number(params, "interval", 20); int duration = (int) number(params, "duration", 100); if (skill == null) return; class Totem implements Runnable { int age; @Override public void run() { if (age > duration) return; age += interval; MythicMobsFabricMod.castExternal(skill, context.caster(), context.trigger(), context.vars()); MythicMobsFabricMod.schedule(interval, this); } } MythicMobsFabricMod.schedule(0, new Totem()); }
    @Override public void orbital(Map<String, String> params, SkillContext context) { String skill = first(params, "ontick", "skill", "s"); if (skill != null) MythicMobsFabricMod.castExternal(skill, context.caster(), context.trigger(), context.vars()); }
    @Override public void slash(Map<String, String> params, SkillContext context) { double amount = number(params, "damage", number(params, "amount", 1)); for (UUID target : context.entityTargets()) damage(target, amount, false); }
    @Override public void chain(Map<String, String> params, SkillContext context) { String skill = first(params, "skill", "s"); if (skill != null) for (UUID target : context.entityTargets()) MythicMobsFabricMod.castExternal(skill, context.caster(), target, context.vars()); }
    @Override public void shoot(String kind, Map<String, String> params, SkillContext context) { projectile(kind, params, context); }
    @Override public void removePotion(UUID target, String effect) { Entity entity = entity(target); if (entity instanceof LivingEntity living) Registries.STATUS_EFFECT.getEntry(identifier(effect)).ifPresent(living::removeStatusEffect); }
    @Override public void setName(UUID target, String name) { Entity entity = entity(target); if (entity != null) { entity.setCustomName(Text.literal(name)); entity.setCustomNameVisible(true); } }
    @Override public void setLevel(UUID target, double level) { ActiveMobState state = active(target); if (state != null) state.vars().put("level", level); }
    @Override public void setFaction(UUID target, String faction) { ActiveMobState state = active(target); if (state != null) state.vars().put("faction", faction); }
    @Override public SkillContext.Point forward(UUID target, double distance) { Entity entity = entity(target); if (entity == null) return new SkillContext.Point("minecraft:overworld", 0, 0, 0); Vec3d vec = entity.getRotationVec(1.0F); return new SkillContext.Point(entity.getWorld().getRegistryKey().getValue().toString(), entity.getX() + vec.x * distance, entity.getY() + vec.y * distance, entity.getZ() + vec.z * distance); }
    @Override public SkillContext.Point spawnLocation(UUID target) { return position(target); }
    @Override public String stance(UUID target) { ActiveMobState state = active(target); return state == null ? "" : state.stance(); }
    @Override public boolean inCombat(UUID target) { return !threatTable(target).isEmpty() || currentTarget(target) != null; }
    @Override public boolean moving(UUID target) { Entity entity = entity(target); return entity != null && entity.getVelocity().lengthSquared() > 0.0025; }
    @Override public double altitude(UUID target) { Entity entity = entity(target); return entity == null ? 0 : entity.getY() - entity.getWorld().getBottomY(); }
    @Override public String blockAt(SkillContext.Point point) { ServerWorld world = world(point); if (world == null) return "minecraft:air"; Block block = world.getBlockState(BlockPos.ofFloored(point.x(), point.y(), point.z())).getBlock(); return Registries.BLOCK.getId(block).toString(); }
    @Override public boolean wearing(UUID target, String itemId) { Entity entity = entity(target); if (!(entity instanceof LivingEntity living)) return false; Identifier id = identifier(itemId); for (ItemStack stack : living.getArmorItems()) if (Registries.ITEM.getId(stack.getItem()).equals(id)) return true; return false; }
    @Override public boolean isPlayer(UUID target) { return entity(target) instanceof ServerPlayerEntity; }
    @Override public boolean blocking(UUID target) { Entity entity = entity(target); return entity instanceof LivingEntity living && living.isBlocking(); }
    @Override public boolean mounted(UUID target) { Entity entity = entity(target); return entity != null && entity.hasVehicle(); }
    @Override public boolean outside(UUID target) { Entity entity = entity(target); return entity != null && entity.getWorld().isSkyVisible(entity.getBlockPos()); }
    @Override public boolean hasPotion(UUID target, String effect) { Entity entity = entity(target); if (!(entity instanceof LivingEntity living)) return false; return Registries.STATUS_EFFECT.getEntry(identifier(effect)).map(living::hasStatusEffect).orElse(false); }
    @Override public String lastSignal(UUID target) { return signals.getOrDefault(target, ""); }
    @Override public String lastDamageCause(UUID target) { return damageCauses.getOrDefault(target, ""); }
    @Override public double lastDamageAmount(UUID target) { return damageAmounts.getOrDefault(target, 0.0); }
    @Override public boolean hasAi(UUID target) { Entity entity = entity(target); return !(entity instanceof MobEntity mob) || !mob.isAiDisabled(); }
    @Override public boolean hasPermission(UUID target, String permission) { MinecraftServer server = MythicMobsFabricMod.server(); Entity entity = entity(target); return server != null && entity instanceof ServerPlayerEntity player && server.getPlayerManager().isOperator(player.getGameProfile()); }
    @Override public boolean ownerOnline(UUID target) { UUID owner = owner(target); MinecraftServer server = MythicMobsFabricMod.server(); return owner != null && server != null && server.getPlayerManager().getPlayer(owner) != null; }
    @Override public UUID owner(UUID target) { Entity entity = entity(target); return entity instanceof TameableEntity tameable ? tameable.getOwnerUuid() : null; }
    @Override public Collection<UUID> threatTable(UUID source) { Map<UUID, Double> table = threat.get(source); if (table == null) return List.of(); return table.entrySet().stream().sorted(Map.Entry.<UUID, Double>comparingByValue().reversed()).map(Map.Entry::getKey).toList(); }
    @Override public Collection<UUID> mobsInRadius(SkillContext.Point point, double radius) { List<UUID> result = new ArrayList<>(); for (UUID id : MythicMobsFabricMod.activeIds()) { SkillContext.Point pos = position(id); if (distanceSquared(point, pos) <= radius * radius) result.add(id); } return result; }
    @Override public Collection<UUID> entitiesInCone(UUID source, double range, double angle) { Entity entity = entity(source); if (entity == null) return List.of(); Vec3d forward = entity.getRotationVec(1.0F).normalize(); List<UUID> result = new ArrayList<>(); for (UUID id : entitiesInRadius(position(source), range, false)) { if (id.equals(source)) continue; Entity other = entity(id); if (other == null) continue; Vec3d delta = other.getPos().subtract(entity.getPos()).normalize(); double degrees = Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, forward.dotProduct(delta))))); if (degrees <= angle * 0.5) result.add(id); } return result; }
    @Override public void setTarget(UUID source, UUID target) { Entity a = entity(source), b = entity(target); if (a instanceof MobEntity mob && b instanceof LivingEntity living) mob.setTarget(living); }
    @Override public void explode(SkillContext.Point point, float power, boolean fire, boolean breakBlocks) { ServerWorld world = world(point); if (world != null) world.createExplosion(null, point.x(), point.y(), point.z(), power, fire, breakBlocks ? World.ExplosionSourceType.MOB : World.ExplosionSourceType.NONE); }
    @Override public void setBlock(SkillContext.Point point, String blockId) { ServerWorld world = world(point); if (world != null) world.setBlockState(BlockPos.ofFloored(point.x(), point.y(), point.z()), Registries.BLOCK.get(identifier(blockId)).getDefaultState()); }
    @Override public void attribute(UUID target, String attribute, double value, String operation, int duration) { Entity entity = entity(target); if (!(entity instanceof LivingEntity living)) return; String key = attribute == null ? "" : attribute.toLowerCase(Locale.ROOT); var type = key.contains("health") ? EntityAttributes.GENERIC_MAX_HEALTH : key.contains("attack") ? EntityAttributes.GENERIC_ATTACK_DAMAGE : EntityAttributes.GENERIC_MOVEMENT_SPEED; var instance = living.getAttributeInstance(type); if (instance != null) { double old = instance.getBaseValue(); instance.setBaseValue(value); if (duration > 0) MythicMobsFabricMod.schedule(duration, () -> { Entity e = entity(target); if (e instanceof LivingEntity le) { var current = le.getAttributeInstance(type); if (current != null) current.setBaseValue(old); } }); } }
    @Override public SkillContext.Point position(UUID target) { Entity entity = entity(target); return entity == null ? new SkillContext.Point("minecraft:overworld", 0, 0, 0) : new SkillContext.Point(entity.getWorld().getRegistryKey().getValue().toString(), entity.getX(), entity.getY(), entity.getZ()); }
    @Override public SkillContext.Point eyePosition(UUID target) { Entity entity = entity(target); return entity == null ? new SkillContext.Point("minecraft:overworld", 0, 0, 0) : new SkillContext.Point(entity.getWorld().getRegistryKey().getValue().toString(), entity.getX(), entity.getEyeY(), entity.getZ()); }
    @Override public UUID currentTarget(UUID target) { Entity entity = entity(target); return entity instanceof MobEntity mob && mob.getTarget() != null ? mob.getTarget().getUuid() : null; }
    @Override public Collection<UUID> entitiesInRadius(SkillContext.Point point, double radius, boolean playersOnly) { ServerWorld world = world(point); if (world == null) return List.of(); Box box = new Box(point.x() - radius, point.y() - radius, point.z() - radius, point.x() + radius, point.y() + radius, point.z() + radius); List<UUID> result = new ArrayList<>(); for (LivingEntity living : world.getEntitiesByClass(LivingEntity.class, box, Entity::isAlive)) if (!playersOnly || living instanceof ServerPlayerEntity) result.add(living.getUuid()); return result; }
    @Override public boolean hasTag(UUID target, String tag) { Entity entity = entity(target); return entity != null && entity.getCommandTags().contains(tag); }
    @Override public boolean hasAura(UUID target, String aura) { return MythicMobsFabricMod.runtimeState().hasAura(target, aura, System.currentTimeMillis()); }
    @Override public double health(UUID target) { Entity entity = entity(target); return entity instanceof LivingEntity living ? living.getHealth() : 0; }
    @Override public double maxHealth(UUID target) { Entity entity = entity(target); return entity instanceof LivingEntity living ? living.getMaxHealth() : 0; }
    @Override public boolean onGround(UUID target) { Entity entity = entity(target); return entity != null && entity.isOnGround(); }
    @Override public boolean crouching(UUID target) { Entity entity = entity(target); return entity instanceof LivingEntity living && living.isSneaking(); }
    @Override public boolean sprinting(UUID target) { Entity entity = entity(target); return entity instanceof LivingEntity living && living.isSprinting(); }
    @Override public boolean lineOfSight(UUID source, UUID target) { Entity a = entity(source), b = entity(target); return a instanceof LivingEntity living && b != null && living.canSee(b); }
    @Override public void setHealth(UUID target, double health) { Entity entity = entity(target); if (entity instanceof LivingEntity living) living.setHealth((float) Math.max(0, Math.min(health, living.getMaxHealth()))); }
    @Override public void ignite(UUID target, int ticks) { Entity entity = entity(target); if (entity != null) entity.setOnFireForTicks(Math.max(0, ticks)); }
    @Override public void lightning(SkillContext.Point point) { ServerWorld world = world(point); if (world == null) return; Entity bolt = EntityType.LIGHTNING_BOLT.create(world); if (bolt != null) { bolt.refreshPositionAndAngles(point.x(), point.y(), point.z(), 0.0F, 0.0F); world.spawnEntity(bolt); } }
    @Override public void command(String command, UUID caster) { MinecraftServer server = MythicMobsFabricMod.server(); if (server != null && command != null && !command.isBlank()) server.getCommandManager().executeWithPrefix(server.getCommandSource(), command.startsWith("/") ? command.substring(1) : command); }
    @Override public void title(UUID target, String title, String subtitle) { Entity entity = entity(target); if (entity instanceof ServerPlayerEntity player) { if (title != null && !title.isBlank()) player.sendMessage(Text.literal(title), true); if (subtitle != null && !subtitle.isBlank()) player.sendMessage(Text.literal(subtitle), false); } }
    @Override public void setAi(UUID target, boolean enabled) { Entity entity = entity(target); if (entity instanceof MobEntity mob) mob.setAiDisabled(!enabled); }
    @Override public void setSpeed(UUID target, double speed) { Entity entity = entity(target); if (entity instanceof LivingEntity living) { var instance = living.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED); if (instance != null) instance.setBaseValue(speed); } }
    @Override public void setGravity(UUID target, boolean enabled) { Entity entity = entity(target); if (entity != null) entity.setNoGravity(!enabled); }

    Entity entity(UUID uuid) {
        if (uuid == null) return null; MinecraftServer server = MythicMobsFabricMod.server(); if (server == null) return null; ServerPlayerEntity player = server.getPlayerManager().getPlayer(uuid); if (player != null) return player; for (ServerWorld world : server.getWorlds()) { Entity entity = world.getEntity(uuid); if (entity != null) return entity; } return null;
    }
    void recordSignal(UUID uuid, String signal) { signals.put(uuid, signal == null ? "" : signal); }
    void recordDamage(UUID uuid, String cause, double amount) { damageCauses.put(uuid, cause == null ? "" : cause); damageAmounts.put(uuid, amount); }
    private ActiveMobState active(UUID uuid) { return MythicMobsFabricMod.active(uuid); }
    private static ServerWorld world() { MinecraftServer server = MythicMobsFabricMod.server(); return server == null ? null : server.getOverworld(); }
    private static ServerWorld world(SkillContext.Point point) { MinecraftServer server = MythicMobsFabricMod.server(); if (server == null) return null; if (point != null && point.world() != null) for (ServerWorld candidate : server.getWorlds()) if (candidate.getRegistryKey().getValue().toString().equals(point.world())) return candidate; return server.getOverworld(); }
    private static Identifier identifier(String raw) { String value = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT).replace(' ', '_'); if (value.isEmpty()) value = "minecraft:air"; return Identifier.of(value.contains(":") ? value : "minecraft:" + value); }
    private static String first(Map<String, String> map, String... keys) { for (String key : keys) { String value = map.get(key); if (value == null) value = map.get(key.toLowerCase(Locale.ROOT)); if (value != null && !value.isBlank()) return value; } return null; }
    private static double number(Map<String, String> map, String key, double fallback) { String raw = map.get(key); if (raw == null) raw = map.get(key.toLowerCase(Locale.ROOT)); try { return raw == null ? fallback : Double.parseDouble(raw); } catch (NumberFormatException e) { return fallback; } }
    private static double distanceSquared(SkillContext.Point a, SkillContext.Point b) { double x = a.x() - b.x(), y = a.y() - b.y(), z = a.z() - b.z(); return x*x + y*y + z*z; }
}
